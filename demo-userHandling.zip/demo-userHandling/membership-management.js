jQuery(document).ready(function ($) {
    let lat, lng;

    // Use My Location button for fetching geolocation
    $('#getLocationBtn').on('click', function (e) {
        e.preventDefault();

        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                function (position) {
                    lat = position.coords.latitude;
                    lng = position.coords.longitude;
                    reverseGeocode(lat, lng);
                },
                function (error) {
                    alert('Error fetching location: ' + error.message);
                },
                {
                    enableHighAccuracy: true,
                    timeout: 5000,
                    maximumAge: 0
                }
            );
        } else {
            alert('Geolocation is not supported by this browser.');
        }
    });

    // Reverse geocode using Nominatim (OpenStreetMap)
    function reverseGeocode(lat, lng) {
        $.get(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&addressdetails=1`, function (data) {
            if (data && data.address) {
                const address = data.display_name;
                $('#user_address').val(address);
            } else {
                alert('Address not found.');
            }
        });
    }

    // Handle form submission for membership registration
    $('#membershipForm').on('submit', function (e) {
        e.preventDefault();

        const user_address = $('#user_address').val();
        const name = $('#name').val();
        const email = $('#email').val();
        const password = $('#password').val();  // New password field
        const coupon_code = $('#coupon_code').val();  // New coupon code field

        if (!name || !email || !user_address || !password) {
            alert('Please fill out all fields.');
            return;
        }

        if (lat && lng) {
            submitMembershipForm(lat, lng, user_address, name, email, password, coupon_code);
        } else {
            // Geocode the address to get lat/lng before form submission
            $.get(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(user_address)}&addressdetails=1&limit=1`, function (data) {
                if (data.length > 0) {
                    lat = data[0].lat;
                    lng = data[0].lon;
                    submitMembershipForm(lat, lng, user_address, name, email, password, coupon_code);
                } else {
                    alert('Unable to find location for the address provided.');
                }
            });
        }
    });

    // Submit the membership form with location data
    function submitMembershipForm(lat, lng, address, name, email, password, coupon_code) {
        $.ajax({
            url: membershipData.ajax_url,
            method: 'POST',
            data: {
                action: 'submit_membership_form',
                lat: lat,
                lng: lng,
                address: address,
                name: name,
                email: email,
                password: password,  // Include password
                coupon_code: coupon_code  // Include coupon code
            },
            success: function (response) {
                if (response.success) {
                    $('#membershipFormResponse').html('<p>Membership request submitted successfully.</p>');
                } else {
                    $('#membershipFormResponse').html('<p>There was an error submitting the form.</p>');
                }
            },
            error: function (xhr, status, error) {
                console.error('Error submitting form:', error);
            }
        });
    }

    // Handle approval of membership requests
    $(document).on('click', '.approve-membership', function (e) {
        e.preventDefault();
        const membershipId = $(this).data('id');

        if (confirm('Are you sure you want to approve this membership?')) {
            $.ajax({
                url: membershipData.ajax_url,
                method: 'POST',
                data: {
                    action: 'approve_membership',
                    id: membershipId,
                },
                success: function (response) {
                    if (response.success) {
                        alert('Membership approved successfully.');
                        location.reload(); // Refresh the page to show updated requests
                    } else {
                        alert('Error approving membership: ' + response.data);
                    }
                },
                error: function (xhr, status, error) {
                    console.error('Error approving membership:', error);
                }
            });
        }
    });

    // Handle decline of membership requests
    $(document).on('click', '.decline-membership', function (e) {
        e.preventDefault();
        const membershipId = $(this).data('id');

        if (confirm('Are you sure you want to decline this membership?')) {
            $.ajax({
                url: membershipData.ajax_url,
                method: 'POST',
                data: {
                    action: 'decline_membership',
                    id: membershipId,
                },
                success: function (response) {
                    if (response.success) {
                        alert('Membership declined successfully.');
                        location.reload(); // Refresh the page to show updated requests
                    } else {
                        alert('Error declining membership: ' + response.data);
                    }
                },
                error: function (xhr, status, error) {
                    console.error('Error declining membership:', error);
                }
            });
        }
    });
});
