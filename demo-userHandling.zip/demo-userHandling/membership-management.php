<?php
/**
 * Plugin Name: Membership Management Plugin
 * Description: A plugin to handle memberships, including registrations, approvals, and address verification.
 * Version: 1.3
 * Author: SAFA YOUSAF
 */

// Enqueue scripts and styles
function membership_management_enqueue_scripts() {
    wp_enqueue_script('bootstrap-js', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js', array('jquery'), null, true);
    wp_enqueue_style('bootstrap-css', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');

    wp_enqueue_script('membership-management-js', plugin_dir_url(__FILE__) . 'membership-management.js', array('jquery'), null, true);
    wp_enqueue_style('membership-management-css', plugin_dir_url(__FILE__) . 'membership-management.css');

    wp_localize_script('membership-management-js', 'membershipData', array(
        'ajax_url' => admin_url('admin-ajax.php')
    ));
}
add_action('wp_enqueue_scripts', 'membership_management_enqueue_scripts');
add_action('admin_enqueue_scripts', 'membership_management_enqueue_scripts');


// Create membership form shortcode
add_shortcode('membership_form', 'membership_form_shortcode');

function membership_form_shortcode() {
    ob_start();
    ?>
    <form id="membershipForm" method="POST">
        <label for="name">Name</label>
        <input type="text" id="name" name="name" required /><br>

        <label for="email">Email</label>
        <input type="email" id="email" name="email" required /><br>

        <label for="password">Password</label>
        <input type="password" id="password" name="password" required /><br>

        <label for="coupon_code">Coupon Code (Optional)</label>
        <input type="text" id="coupon_code" name="coupon_code" /><br>

        <label for="user_address">Address</label>
        <input type="text" id="user_address" name="user_address" required /><br>

        <button id="getLocationBtn">Use My Location</button>
        <input type="submit" value="Submit" />
    </form>
    <div id="membershipFormResponse"></div>
    <?php
    return ob_get_clean();
}

// Handle form submission via AJAX
add_action('wp_ajax_submit_membership_form', 'submit_membership_form');
add_action('wp_ajax_nopriv_submit_membership_form', 'submit_membership_form');

function submit_membership_form() {
    global $wpdb;

    // Sanitize and validate input data
    $name = sanitize_text_field($_POST['name']);
    $email = sanitize_email($_POST['email']);
    $password = sanitize_text_field($_POST['password']);
    $hashed_password = wp_hash_password($password); // Hash the password before storing it
    $coupon_code = sanitize_text_field($_POST['coupon_code']);
    $address = sanitize_text_field($_POST['address']);
    $lat = floatval($_POST['lat']);
    $lng = floatval($_POST['lng']);

    // Insert membership request into the database
    $inserted = $wpdb->insert(
        $wpdb->prefix . 'membership_requests',
        [
            'name' => $name,
            'email' => $email,
            'password' => $hashed_password,  // Store hashed password
            'coupon_code' => $coupon_code,   // Store coupon code
            'address' => $address,
            'latitude' => $lat,
            'longitude' => $lng,
            'status' => 'pending',  // Default to pending
            'registered_at' => current_time('mysql')
        ]
    );

    if ($inserted) {
        wp_send_json_success('Membership request submitted successfully.');
    } else {
        wp_send_json_error('Error inserting membership request: ' . $wpdb->last_error);
    }
}

// Create table for storing membership requests
register_activation_hook(__FILE__, 'create_membership_requests_table');
function create_membership_requests_table() {
    global $wpdb;

    $table_name = $wpdb->prefix . 'membership_requests';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        name varchar(255) NOT NULL,
        email varchar(255) NOT NULL,
        password varchar(255) NOT NULL,
        coupon_code varchar(50),
        address text NOT NULL,
        latitude float NOT NULL,
        longitude float NOT NULL,
        status varchar(20) DEFAULT 'pending' NOT NULL,
        registered_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// Admin menu with submenus for Accepted, Pending, and Declined requests
add_action('admin_menu', 'membership_management_menu');

function membership_management_menu() {
    add_menu_page(
        'Membership Management',
        'Memberships',
        'manage_options',
        'membership-management',
        'membership_management_dashboard',
        'dashicons-admin-users',
        6
    );

    add_submenu_page(
        'membership-management',
        'Pending Approvals',
        'Pending Approvals',
        'manage_options',
        'pending-approvals',
        'pending_approvals_page'
    );

    add_submenu_page(
        'membership-management',
        'Accepted Requests',
        'Accepted Requests',
        'manage_options',
        'accepted-requests',
        'accepted_requests_page'
    );

    add_submenu_page(
        'membership-management',
        'Declined Requests',
        'Declined Requests',
        'manage_options',
        'declined-requests',
        'declined_requests_page'
    );
}

// Main dashboard page
function membership_management_dashboard() {
    echo '<h1>Membership Management Dashboard</h1>';
    echo '<p>Welcome to the Membership Management system. Use the submenus to view pending, accepted, or declined requests.</p>';
}

// Pending Approvals Page
function pending_approvals_page() {
    global $wpdb;
    $pending_memberships = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}membership_requests WHERE status = 'pending'");

    echo '<h1>Pending Membership Approvals</h1>';
    display_membership_table($pending_memberships);
}

// Accepted Requests Page
function accepted_requests_page() {
    global $wpdb;
    $accepted_memberships = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}membership_requests WHERE status = 'approved'");

    echo '<h1>Accepted Membership Requests</h1>';
    display_membership_table($accepted_memberships);
}

// Declined Requests Page
function declined_requests_page() {
    global $wpdb;
    $declined_memberships = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}membership_requests WHERE status = 'declined'");

    echo '<h1>Declined Membership Requests</h1>';
    display_membership_table($declined_memberships);
}

// Helper function to display membership requests in a table
function display_membership_table($memberships) {
    if (empty($memberships)) {
        echo '<p>No membership requests found.</p>';
        return;
    }

    echo '<table class="wp-list-table widefat fixed striped">';
    echo '<thead><tr><th>Name</th><th>Email</th><th>Coupon Code</th><th>Address</th><th>Status</th><th>Actions</th></tr></thead>';
    echo '<tbody>';

    foreach ($memberships as $membership) {
        echo '<tr>';
        echo '<td>' . esc_html($membership->name) . '</td>';
        echo '<td>' . esc_html($membership->email) . '</td>';
        echo '<td>' . esc_html($membership->coupon_code) . '</td>';  // Display coupon code
        echo '<td>' . esc_html($membership->address) . '</td>';
        echo '<td>' . esc_html($membership->status) . '</td>';
        echo '<td>';
        echo '<a href="#" class="button approve-membership" data-id="' . $membership->id . '">Approve</a> ';
        echo '<a href="#" class="button decline-membership" data-id="' . $membership->id . '">Decline</a>';
        echo '</td>';
        echo '</tr>';
    }

    echo '</tbody>';
    echo '</table>';
}

// Handle approval of membership requests
add_action('wp_ajax_approve_membership', 'approve_membership');
function approve_membership() {
    global $wpdb;

    $id = intval($_POST['id']);
    $updated = $wpdb->update(
        $wpdb->prefix . 'membership_requests',
        ['status' => 'approved'], // Update status to 'approved'
        ['id' => $id]
    );

    if ($updated !== false) {
        wp_send_json_success('Membership approved.');
    } else {
        wp_send_json_error('Error approving membership.');
    }
}

// Handle decline of membership requests
add_action('wp_ajax_decline_membership', 'decline_membership');
function decline_membership() {
    global $wpdb;

    $id = intval($_POST['id']);
    $updated = $wpdb->update(
        $wpdb->prefix . 'membership_requests',
        ['status' => 'declined'], // Update status to 'declined'
        ['id' => $id]
    );

    if ($updated !== false) {
        wp_send_json_success('Membership declined.');
    } else {
        wp_send_json_error('Error declining membership.');
    }
}
